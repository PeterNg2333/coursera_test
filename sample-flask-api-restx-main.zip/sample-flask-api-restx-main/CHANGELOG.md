# Change Log

## [0.0.2] 2021-01-31
### Improvements

- Added new methods:
  - Delete Item
  - Update Item
  - Complete `get all items` request

## [0.0.1] 2021-01-31
### Initial Release

- Persistance: SQLite3  
- Stack: Flask / FLask-RestX / SQLAlchemy
- Minimal API version

